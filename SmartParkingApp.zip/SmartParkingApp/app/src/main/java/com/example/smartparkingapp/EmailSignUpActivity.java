package com.example.smartparkingapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class EmailSignUpActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.email_signup);
    }
}
